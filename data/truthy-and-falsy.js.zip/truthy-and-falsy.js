/*
let x = 0;
if (x) {
  // This block will NOT be executed because x is falsy (0 is falsy)
}


let y = 'hello';
if (y) {
  // This block WILL be executed because y is truthy ('hello' is a non-empty string)
}
*/
/*
let x = null;
let y = 'hello';
let z = 'world';

console.log(x && y && z); // Output: null (x is falsy)
console.log(y && z);      // Output: 'world' (all truthy, returns last truthy value)
*/
/*

let x = null;
let y = 'hello';
let z = 'world';

console.log(x || y || z); // Output: 'hello' (first truthy value)
console.log(x || z);      // Output: 'world' (x is falsy, z is truthy)
*/

let greeting = 'Hello'; 
let name = 'John'; 
let age = 25; 
alert(greeting + ', ' + name + '! You are ' + age + ' years old.');